<div style="padding: 10px; border: 1px solid red; background-color: pink;">
<strong>Alert:</strong> {{ $message??"Alert" }}
</div>  